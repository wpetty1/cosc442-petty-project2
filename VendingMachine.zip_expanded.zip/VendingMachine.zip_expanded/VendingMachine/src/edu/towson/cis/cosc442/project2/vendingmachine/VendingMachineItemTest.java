package edu.towson.cis.cosc442.project2.vendingmachine;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class VendingMachineItemTest {
	/** the Vending Machine Item test object. */
	private VendingMachineItem venditem;
	
	/** Sets up VendingMachineItem test object */
	@Before
	public void setUp() throws Exception {
		venditem = new VendingMachineItem("name", 00);
	}

	/** Test for VendingMachineItem getName method */
	@Test
	public void testGetName() {
		assertEquals("name", venditem.getName());
	}
	
	/** Test for VendingMachineItem getPrice method */
	@Test
	public void testGetPrice() {
		assertEquals(0.0,venditem.getPrice(), 0.0);
	
	}
	/** Test for VendingMachineItem test object */
	@Test
	public void testVendingMachineItem() {
		venditem = new VendingMachineItem("name", 00);
	}
}
