package edu.towson.cis.cosc442.project2.vendingmachine;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class VendingMachineTest {
	/** the Vending Machine test object. */
	private VendingMachine vend;
	private VendingMachineItem item;

	
	
	@Before
	public void setUp() throws Exception {
		item = new VendingMachineItem("string",0.0);
		vend = new VendingMachine();
		
	
	}

	@Test
	/** Testing amount > 0 for InsertMoney method */
	public void testInsertMoney() {
		assertEquals(0.01, vend.balance,0.01);
	}
	/** Test for SlotIndex in AddItem method */
	@Test
	public void testAddItem() {
	assertEquals("A", VendingMachine.A_CODE);
	}
	
	/** Test for VendingMachineItem getName method */
	@Test
	public void testMakePurchase() {
		assertEquals(item.getPrice(), vend.balance, 0);
	}
	
	/** Test for SlotIndex in RemoveItem method */
	@Test
	public void testRemoveItem() {
		assertEquals("A", VendingMachine.A_CODE);
	}
	
	/** Test for balance in GetBalance method */
	
	@Test
	public void testGetBalance() {
		assertEquals(0.0, vend.balance, 0.0);
	}
	
	/** Test for balance == 0 in ReturnChange method */

	@Test
	public void testReturnChange() {
	assertEquals(0, vend.balance,0);
		
	}
}
